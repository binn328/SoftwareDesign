본 어플리케이션은 MesloLGS NF 폰트를 사용한 

Windows Terminal 에서 테스트하였습니다.

해당 폴더에서 Windows Terminal 앱을 실행한 후 

java -jar ./PokerManager.jar

을 입력하시면 실행됩니다.

단순히 Run.bat을 실행하여도 되지만, 

카드가 밀려보이는 의도하지 않은 출력이 발생할 수 있습니다.



