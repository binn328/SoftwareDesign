import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        while(true) {
            PokerManager pokerManager = new PokerManager();
            pokerManager.run();
        }
    }
}